<!DOCTYPE html>
<html>
<head>
<title>Ejemplo jQuery</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script src="jquery-1.8.2.min.js" type="text/javascript"></script>
<script src="funciones.js" type="text/javascript"></script>
</head>
<body>
<form name="formulario1">
    <p>Indique el valor a buscar<br /><input type="text" name="c1" id="c1"></p>
    <p><input type="button" name="c2" id="c2" value="Buscar"></p>
    <div id="resultado"></div>
</form>
</body>
</html>

