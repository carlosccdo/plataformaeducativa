<?php

	/* CAPTURA LOS DATOS ENVIADOS DESDE LOS CAMPOS DE TEXTO */
	$c1=$_POST['c1'];
	
	/* DEFINICION DE LAS VARIABLES CON LOS DATOS DE CONEXION */
	$se = "localhost";
	$us = "root";
	$co = "borja";
	$bd = "bd1";	
	
	/* PREPARACION DE LA CONEXION */	
	$mysqli = new mysqli($se, $us, $co, $bd);
	
	/* ESTABLECIMIENTO DE LA CONEXION */	
	if ($mysqli->connect_errno) {
		printf("Error en la conexion: %s\n", $mysqli->connect_error);
		exit();
	}	
	
	// Aplicamos la configuración regional española.
	// La pagina web debe contemplarla:
	// <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
	// Al igual que la tabla y los campos:
	// CREATE TABLE IF NOT EXISTS `t1` (
	//  `c1` int(11) NOT NULL AUTO_INCREMENT,
	//  `c2` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
	//  `c3` varchar(10) CHARACTER SET utf8 DEFAULT NULL,  
	//  PRIMARY KEY (`c1`)
	// ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
	$mysqli->set_charset("utf8");	

	/* SELECION DE LOS DATOS */
	$resultado = $mysqli->query("SELECT nombre, telefono FROM personas WHERE nombre='$c1' OR telefono='$c1' ORDER BY nombre ASC");	
	/* VOLCADO DE LOS DATOS */
	while ($fila = $resultado->fetch_assoc()) {
		echo $fila['nombre'] . " " . $fila['telefono'] . "<br />" ;
	}	
	/* LIBERAR LA MATRIZ QUE ALBERGA EL CONJUNTO DE RESULTADOS */
	$resultado->free();
	/* CIERRE DE LA CONEXION */
	$mysqli->close();

?>
