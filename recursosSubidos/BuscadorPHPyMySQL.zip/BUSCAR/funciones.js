// INICIO DOCUMENT.READY
$(document).ready(function() {
	
	// INICIO C1.CLICK
	$("#c2").click(function(event) {
		
		// INICIO FUNCION AJAX
		$.ajax({
		  type: "POST",
		  url: "buscar.php",
		  data: { c1: $("#c1").val() }
		}).done(function( msg ) {
		  $("#resultado").html( msg ); 	  
		});	
		// FINAL FUNCION AJAX

		// LIMPIEZA DE CONTROLES
		$("#c1").val( "" );
	
	});
	// FINAL C1.CLICK
	
});
// FINAL DOCUMENT.READY	
